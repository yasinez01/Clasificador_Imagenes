import numpy as np
import cv2
import os
import glob
from sklearn.decomposition import PCA

"""
Dividir la imagen en bloques disjuntos de NxN píxeles (por ejemplo, N = 16). A estos
bloques les llamaremos celdas.
"""
def recorta_imagen(imagen, n):
    i = imagen.shape[0]
    j = imagen.shape[1]
    if (i % n != 0): #Recortar filas
        dif = i % n
        imagen = imagen[0:i-dif, :]
    if (j % n != 0): #Recortar columnas
        dif = j % n
        imagen = imagen[:, 0:j-dif]
    
    return imagen

"""
Para cada píxel de la celda, lo vamos a comparar con cada uno de sus 8 vecinos,
empezando, por ejemplo, por el de arriba a la izquierda y siguiendo la dirección de las
agujas del reloj. Los valores de los 8 vecinos los vamos a sustituir por un 0 o un 1 en función de si el
vecino es menor (0) o mayor (1) que el píxel central.
Una vez realizado este cambio, si tomamos el valor de los 8 vecinos siguiendo la misma
distribución que en el paso anterior, nos generará un número binario que, al
transformarlo a decimal, resultará en un número entre 0 y 255 y modificamos el valor del pixel con el resultado
"""
def sustitucion(bloque): 
    n = bloque.shape[0]
    bloque_con_borde=cv2.copyMakeBorder(bloque, 1, 1, 1, 1, cv2.BORDER_REPLICATE)
    resultado = np.zeros_like(bloque, dtype=np.uint8)

    for i in range(1, n+1):
        for j in range(1, n+1):
            """            
            # en caso de sentido contrario, empezando por el mismo vecino
            vecinos = [bloque_con_borde[i-1, j-1], bloque_con_borde[i, j-1], bloque_con_borde[i+1, j-1],
                bloque_con_borde[i+1, j], bloque_con_borde[i+1, j+1], bloque_con_borde[i, j+1],
                bloque_con_borde[i-1, j+1], bloque_con_borde[i-1, j]]
            """
            vecinos = [bloque_con_borde[i-1, j-1], bloque_con_borde[i-1, j], bloque_con_borde[i-1, j+1],
                bloque_con_borde[i, j+1], bloque_con_borde[i+1, j+1], bloque_con_borde[i+1, j],
                bloque_con_borde[i+1, j-1], bloque_con_borde[i, j-1]]
            central = bloque_con_borde[i, j]

            # vecinos = np.where(np.array(vecinos) < central, 0, 1)  # este es mas lento que el de abajo
            # comprension de lista, es mas rapido que un for y para el caso de 8 elementos no deberia tardar mucho
            vecinos = [0 if vecino < central else 1 for vecino in vecinos]  # Probar con el <=

            decimal_resultado =  np.packbits(vecinos)
            resultado[i-1, j-1] =decimal_resultado

    return resultado

def sustitucion_uniforme(bloque, uniforme_value):
    n = bloque.shape[0]
    bloque_con_borde = cv2.copyMakeBorder(bloque, 1, 1, 1, 1, cv2.BORDER_REPLICATE)
    resultado = np.zeros_like(bloque, dtype=np.uint8)

    for i in range(1, n+1):
        for j in range(1, n+1):
            vecinos = [bloque_con_borde[i-1, j-1], bloque_con_borde[i-1, j], bloque_con_borde[i-1, j+1],
                bloque_con_borde[i, j+1], bloque_con_borde[i+1, j+1], bloque_con_borde[i+1, j],
                bloque_con_borde[i+1, j-1], bloque_con_borde[i, j-1]]
            central = bloque_con_borde[i, j]
        
            # vecinos = np.where(np.array(vecinos) < central, 0, 1)  # este es mas lento que el de abajo
            vecinos = [0 if vecino < central else 1 for vecino in vecinos]

            transiciones = sum([1 for k in range(len(vecinos)-1) if vecinos[k] != vecinos[k + 1]])
            if transiciones > 2:
                decimal_resultado = uniforme_value
            else:
                decimal_resultado = int(''.join(map(str, vecinos)), 2)
            resultado[i-1, j-1] = decimal_resultado
    return resultado

def sustitucionRGB(bloque): 
    n = bloque.shape[0]
    bloque_con_borde=cv2.copyMakeBorder(bloque, 1, 1, 1, 1, cv2.BORDER_REPLICATE)
    resultado = np.zeros_like(bloque, dtype=np.uint8)

    for i in range(1, n+1):
        for j in range(1, n+1):
            """            
            # en caso de sentido contrario, empezando por el mismo vecino
            vecinos = [bloque_con_borde[i-1, j-1], bloque_con_borde[i, j-1], bloque_con_borde[i+1, j-1],
                bloque_con_borde[i+1, j], bloque_con_borde[i+1, j+1], bloque_con_borde[i, j+1],
                bloque_con_borde[i-1, j+1], bloque_con_borde[i-1, j]]
            """
            vecinos = [bloque_con_borde[i-1, j-1], bloque_con_borde[i-1, j], bloque_con_borde[i-1, j+1],
                bloque_con_borde[i, j+1], bloque_con_borde[i+1, j+1], bloque_con_borde[i+1, j],
                bloque_con_borde[i+1, j-1], bloque_con_borde[i, j-1]]
            central = bloque_con_borde[i, j]

            # vecinos = np.where(np.array(vecinos) < central, 0, 1)  # este es mas lento que el de abajo
            # comprension de lista, es mas rapido que un for y para el caso de 8 elementos no deberia tardar mucho
            vecinos = np.where(np.array(vecinos) < central , 0, 1)  # Probar con el <=

            decimal_resultado = np.packbits(vecinos.T)
            resultado[i-1, j-1] = decimal_resultado

    return resultado

"""
Una vez realizado esto para cada píxel de la celda, vamos a construir un histograma de los NxN
píxeles obtenidos. El valor del histograma será el vector de características asociados a la celda
"""

def construir_histograma(celda,canal):
    h = cv2.calcHist([celda],[canal],None,[256],[0,256]).flatten()
    return h

"""
Por último, si concatenamos todos los histogramas de la imagen siguiendo el orden de las celdas,
obtendremos el vector de características de la imagen.
"""
def vector_caracteristicas(imagen, n):
    vector = []
    imagen = recorta_imagen(imagen,n)
    a,b = imagen.shape[:2]

    for i in range(int(a//n)):
        for j in range(int(b//n)):
            bloque = imagen[n*i:n*(i+1),n*j:n*(j+1)] 
            vector.append(construir_histograma(sustitucion(bloque), 0))
    return np.concatenate(vector)

def vector_caracteristicas_uniforme(imagen, n):
    vector = []
    imagen = recorta_imagen(imagen,n)
    a,b = imagen.shape[:2]
    for i in range(int(a//n)):
        for j in range(int(b//n)):
            bloque = imagen[n*i:n*(i+1),n*j:n*(j+1)]
            vector.append(construir_histograma(sustitucion_uniforme(bloque, 59), 0))
    return np.concatenate(vector)

def vector_caracteristicasRGB(imagen, n):
    vector = []
    imagen = recorta_imagen(imagen,n)
    a,b = imagen.shape[:2]

    for i in range(int(a//n)):
        for j in range(int(b//n)):
            bloque = imagen[n*i:n*(i+1),n*j:n*(j+1)] 
            sustituto = sustitucionRGB(bloque)
            vector.append(np.concatenate([construir_histograma(sustituto, canal) for canal in range(3)]))
    return np.concatenate(vector)

def pca(imagenes_train,imagenes_test,numeroComponentes):
    """
    Esta función recibe un conjunto de vectores de train y de test y les aplica 
    análisis de las componentes principales.
    :param imagenes_train: imágenes con las que entrenar PCA
    :param imagenes_test : imágenes a las que aplicarles la transformación PCA sin haber entrenado con ellas
    :param numeroComponentes: numero de componentes que conservará PCA
    """
    pca = PCA(numeroComponentes)
    pca.fit(imagenes_train)
    imagenes_train = pca.transform(imagenes_train)
    imagenes_test = pca.transform(imagenes_test)
    return imagenes_train,imagenes_test



"""
Aplicar un filtro espacial de aproximación de la derivada parcial en ambas direcciones
mediante las máscaras de convolución −1 0 1 y −1 0 1 
"""
def filtro(imagen, mascara):
    dif=len(mascara)//2
    imagenPrima = np.zeros_like(imagen)
    imagen_ampliada = cv2.copyMakeBorder(imagen,dif,dif,dif,dif,cv2.BORDER_REPLICATE)
    for i in range(dif,len(imagen)+dif):
        for j in range(dif,len(imagen[0])+dif):
            imagenPrima[i-dif,j-dif] = np.sum(np.multiply(imagen_ampliada[i-dif:i+dif+1,j-dif:j+dif+1],mascara))
    return imagenPrima

"""
Calcular la magnitud y orientación de gradiente. Para la orientación utilizar la función
np.arctan2 junto con np.rad2deg para obtener la orientación en grados. Además,
realizar la operación orientación % 180 para obtener todas las orientaciones en positivo
y entre 0 y 180 grados
"""
def gradiente(imagen):
    m_g_x = filtro(imagen, np.array([-1,0,1]))
    m_g_y = filtro(imagen, np.array([[-1],[0],[1]]))
    E = np.sqrt(m_g_x**2+m_g_y**2)
    
    Phi = np.rad2deg(np.arctan2(m_g_y,m_g_x))
    Phi[Phi < 0] *= -1   # Solo positivos

    bins = np.array([-1, 20, 40, 60, 80, 100, 120, 140, 160, 181])
    Phi = ((np.digitize(Phi, bins) -1) % 9).astype(int)
    
    return E, Phi

"""
Construiremos un histograma para cada una de las celdas. El histograma estará formado
por 9 valores o bins, el primer bin servirá para las orientaciones entre 0 y
20 grados; el segundo para las orientaciones entre 20 y 40; y así sucesivamente hasta
las orientaciones entre 160 y 180.
Para rellenar el histograma, rellenaremos el histograma mediante el valor de la magnitud del
gradiente. Por ejemplo, si el primer píxel de la celda tiene orientación 45º, entonces en
el bin asociado a 45º (tercer bin) sumaremos el valor de la magnitud en dicho punto.
Una vez sumadas las magnitudes en cada correspondiente bin, tendremos un vector de
9 valores para cada celda.
"""
def crear_histograma_9_bins(E,Phi):
    E = E.reshape((-1,1))
    Phi = Phi.reshape((-1,1))
    bins = np.zeros((9))

    for i in range(Phi.shape[0]):
        bins[Phi[i,0]] += E[i, 0]

    # Vamos a normalizar el histograma, dividiéndolo entre el valor de la norma euclídea de
    # los 9 valores (raíz cuadrada de la suma al cuadrado de los valores)
    norma = np.linalg.norm(bins)
    bins_normalizado = bins / norma if norma != 0 else bins

    return bins_normalizado

def crear_histograma_9_bins_sin_normalizar(E,Phi):
    E = E.reshape((-1,1))
    Phi = Phi.reshape((-1,1))
    bins = np.zeros((9))

    for i in range(Phi.shape[0]):
        bins[Phi[i,0]] += E[i, 0]

    return bins

def vector_caracteristicas2(imagen, n):
    vector = []
    imagen = recorta_imagen(imagen,n)
    a, b = imagen.shape[:2]

    for i in range(int(a//n)):
        for j in range(int(b//n)):
            bloque = imagen[n*i:n*(i+1), n*j:n*(j+1)]
            #filtro=filtro_Aproximacion(bloque)
            E, Phi = gradiente(bloque)
            h = crear_histograma_9_bins(E, Phi)
            vector.append(np.array(h))
    return np.concatenate(vector)

def obtener_bins_todos(imagen, n):

    imagen = recorta_imagen(imagen,n)
    a, b = imagen.shape[:2]
    bins_todos = np.zeros((int(a//n), int(b//n), 9))
    
    # recolectar todos los bins
    for i in range(int(a//n)):
        for j in range(int(b//n)):
            bloque = imagen[n*i:n*(i+1), n*j:n*(j+1)]
            #filtro=filtro_Aproximacion(bloque)
            E, Phi = gradiente(bloque)
            bins_todos[i,j] = np.uint8(255 * crear_histograma_9_bins_sin_normalizar(E, Phi))

    return bins_todos

# Sin probar
def normalizar_bins_MxM(bins_MxM):
    bins = bins_MxM.reshape(-1)
    norma = np.linalg.norm(bins)
    bins_normalizado = bins / norma if norma != 0 else bins

    return bins_normalizado
"""
- Normalizar el histograma de las celdas teniendo en cuenta los histogramas vecinos. Para
ello, vamos a definir el concepto de bloque como un conjunto de MxM celdas (por
ejemplo, M = 2). De esta manera, tomaremos los 𝑀2 histogramas (9𝑀2 valores), y los
normalizaremos por la norma de dichos valores.
- Además de lo anterior, podemos hacer
que los bloques de MxM celdas se vayan moviendo de 1 en 1 (como en un filtro espacial),
generando así cierto solapamiento a la hora de calcular las normalizaciones.
Evidentemente, esto hará que el vector de características sea más grande (por el
solapamiento), pero puede obtener características de mayor calidad. Siguiente con el
ejemplo, una imagen de 128x128 y tomando N=16, M=2, y con un paso de 1 en 1 entre
bloques, generaría 64 celdas distintas, que agruparemos en 49 bloques distintos (7x7),
generando así un vector de características de 1764 elementos.
"""

# Sin probar
def vector_caracteristicas2_con_MxM(imagen, n, m):
    bins_normalizado = []
    bins_todos = obtener_bins_todos(imagen, n)
    #normalizar con bins vencinos
    dif = int(m//2)
    # para todos los bloques de celdas MxM
    for i in range(0, bins_todos.shape[0] -dif):
        for j in range(0, bins_todos.shape[1] -dif):
            bins_normalizado.append(normalizar_bins_MxM(bins_todos[i:i+m, j:j+m]))

    return np.concatenate(bins_normalizado)

"""
    Esta función lee una carpeta y extrae sus archivos, dividiéndolos
    en train y en test según el nombre de la subcarpeta.
    :param animal: Nombre del animal que deseas cargar ('cat', 'dog', etc.)
    :param path: Dirección donde se encuentran las carpetas con las imágenes que queremos leer
    :param tamanio_imagen: Tamaño al que queremos dejar todas las imágenes
"""
def crea_dataset(animal, train, path='dataset', tamanio_imagen=(260, 260)):
    imagenes_train = glob.glob(os.path.join(path, 'train_' + train, animal, '*'))
    imagenes_test = glob.glob(os.path.join(path, 'test', animal, '*'))

    # train
    y_train = [animal] * len(imagenes_train)  # Vector de clases, guardaré el nombre del animal
    X_train = [cv2.resize(cv2.imread(img.replace('\\','/')), tamanio_imagen) for img in imagenes_train]
    X_train = np.asarray(X_train, dtype=np.uint8)

    # test
    y_test = [animal] * len(imagenes_test)  # Vector de clases, guardaré el nombre del animal
    X_test = [cv2.resize(cv2.imread(img.replace('\\','/')), tamanio_imagen) for img in imagenes_test]
    X_test = np.asarray(X_test, dtype=np.uint8)
   
    return X_train, y_train, X_test, y_test